# Alibaba US Region (No Login)

把 `alibaba.com` 永久切换到美国（或英、德、加、澳、日）视角的 Chrome 扩展（Manifest V3）。**无需登录账号**即可查看美国地区的价格、运费、可售商家。

## 解决的问题

- 直接在阿里页面点「交货至」改成美国 → 强制弹出登录窗口（baxia iframe）
- 不登录就只能用默认的全球/中国视角看价格，对跨境选品不准

## 方案

在浏览器 cookie 层面把阿里的区域偏好直接写好：

| Cookie | 作用 | 默认值 |
|---|---|---|
| `sc_g_cfg_f` | 站点 / 币种 / 语言 | `sc_b_currency=USD&sc_b_locale=en_US&sc_b_site=US` |
| `_us_lang` | 语言偏好 | `en_US` |
| `xman_us_f` | 区域记忆 | `ctry=US&language=en_US&x_currency=USD` |
| `intl_locale` | 国际化 locale | `en_US` |

cookie 在 `.alibaba.com` 域、`HttpOnly`，因此用 `chrome.cookies` API 在 background service worker 里写；每次跳转 alibaba.com 前再校准一次，避免被服务端覆盖。

附带把 `baxia` 强制登录 iframe 和登录弹窗藏起来，避免遗留弹窗挡住操作。

## 安装

1. 打开 `chrome://extensions`
2. 右上角开启「开发者模式」
3. 点「加载已解压的扩展程序」→ 选 `C:\Users\Administrator\Desktop\alibaba-no-login-popup`
4. 工具栏点扩展图标，选 `United States`，点「应用区域并刷新当前页」

## 验证

- 打开任意商品详情页，例如：
  `https://www.alibaba.com/product-detail/Happy-Build-Hot-Sell-YC-23043_1601522517442.html`
- 页面右上角「Ship to」应该自动显示 🇺🇸 US；价格/MOQ 按美国视角；不再弹登录框

## 文件结构

```
alibaba-no-login-popup/
├── manifest.json     # MV3 配置（permissions: cookies, scripting, webNavigation）
├── background.js     # service worker：写入 US 区域 cookie
├── content.js        # 注入页面：屏蔽 baxia 登录弹窗
├── content.css       # CSS 兜底
├── popup.html        # 工具栏 UI：开关 + 区域选择
├── popup.js          # 弹窗逻辑
├── icon.png
└── README.md
```

## 已知限制

- 某些 B2B 询盘 / 订单页面是「**功能级**」必须登录（发询盘、下单、查供应商联系方式），扩展无法绕过 —— 那是服务端鉴权。
- 阿里促销期偶尔会按 IP 强制识别区域，可能短暂忽略 cookie；刷新或换页后会恢复。
- 偏好被覆盖时，再次点工具栏「应用区域并刷新当前页」即可。
