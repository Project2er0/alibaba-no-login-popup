const ENABLED_KEY = "ali_region_enabled";
const REGION_KEY = "ali_region_value";

const PRESETS = {
  US: { country: "US", currency: "USD", locale: "en_US" },
  GB: { country: "GB", currency: "GBP", locale: "en_GB" },
  DE: { country: "DE", currency: "EUR", locale: "en_US" },
  CA: { country: "CA", currency: "CAD", locale: "en_US" },
  AU: { country: "AU", currency: "AUD", locale: "en_US" },
  JP: { country: "JP", currency: "JPY", locale: "ja_JP" },
};

const $ = (id) => document.getElementById(id);

function setStatus(msg) {
  $("status").textContent = msg || "";
  if (msg) setTimeout(() => ($("status").textContent = ""), 2500);
}

// Init
chrome.storage.sync.get([ENABLED_KEY, REGION_KEY], (res) => {
  $("enabled").checked = res && Object.prototype.hasOwnProperty.call(res, ENABLED_KEY) ? !!res[ENABLED_KEY] : true;
  const r = (res && res[REGION_KEY]) || PRESETS.US;
  $("country").value = r.country || "US";
});

$("enabled").addEventListener("change", () => {
  if ($("enabled").checked) {
    const region = PRESETS[$("country").value] || PRESETS.US;
    chrome.runtime.sendMessage({ type: "apply_region", region }, () => setStatus("已启用"));
  } else {
    chrome.runtime.sendMessage({ type: "clear_region" }, () => setStatus("已关闭"));
  }
});

$("apply").addEventListener("click", async () => {
  const region = PRESETS[$("country").value] || PRESETS.US;
  chrome.runtime.sendMessage({ type: "apply_region", region }, async () => {
    setStatus("已应用，刷新中…");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id && tab.url && /alibaba\.com/.test(tab.url)) {
      chrome.tabs.reload(tab.id);
      window.close();
    }
  });
});

$("clean").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      const KILL = /(login|signin|sign-in|loginGuide|forceLogin|LoginPopup|signin-mask|mask|overlay|backdrop|baxia)/i;
      document.querySelectorAll(
        'iframe#baxia-dialog-content, iframe[src*="login.alibaba.com" i], iframe[src*="passport.alibaba.com" i], #baxia-dialog, #baxia-dialog-mask, [id^="baxia-"], [class^="baxia-"]'
      ).forEach((n) => n.remove());
      document.querySelectorAll('div[role="dialog"], div[class*="dialog"], div[class*="popup"], div[class*="Modal"], div[class*="modal"]').forEach((n) => {
        if (KILL.test(n.className || "")) n.remove();
      });
      for (const el of [document.documentElement, document.body]) {
        el.classList.remove("next-dialog-open", "next-overlay-open", "no-scroll", "modal-open", "overflow-hidden");
        if (el.style.overflow === "hidden") el.style.overflow = "";
        if (el.style.position === "fixed") el.style.position = "";
      }
    },
  });
  setStatus("已清理");
});
