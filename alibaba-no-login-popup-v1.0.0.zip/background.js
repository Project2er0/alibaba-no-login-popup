/* Alibaba US Region — background service worker
 *
 * 作用：把 alibaba.com 的「交货至 / 币种 / 语言」相关 cookie 强制写成 US/USD/en_US，
 * 让服务端按美国视角返回价格、运费、可售商家，从而避免切换国家时被强制登录。
 *
 * 关键 cookie（阿里前端会读取这些值决定区域偏好）：
 *   sc_g_cfg_f : sc_b_currency=USD&sc_b_locale=en_US&sc_b_site=US
 *   _us_lang   : en_US
 *   xman_us_f  : x_l=1; ctry=US; language=en_US ...
 *   xman_t     : 区域 token，存在即可
 *
 * 注意：HttpOnly cookie 必须在 background 用 chrome.cookies API 写，content script 写不了。
 */

const DEFAULT_REGION = {
  country: "US",
  currency: "USD",
  locale: "en_US",
};

const ENABLED_KEY = "ali_region_enabled";
const REGION_KEY = "ali_region_value";

// 一年后过期
function expirationDate() {
  return Math.floor(Date.now() / 1000) + 365 * 24 * 3600;
}

const COOKIE_DOMAINS = [".alibaba.com", "www.alibaba.com", ".sale.alibaba.com"];

function buildCookies(region) {
  const { country, currency, locale } = region;
  const scgcfg = `sc_b_currency=${currency}&sc_b_locale=${locale}&sc_b_site=${country}`;
  const xmanusf = `x_l=1^|ctry=${country}^|language=${locale}^|x_locale=${locale}^|x_currency=${currency}`;
  return [
    { name: "sc_g_cfg_f", value: scgcfg },
    { name: "_us_lang", value: locale },
    { name: "xman_us_f", value: xmanusf },
    { name: "intl_locale", value: locale },
    { name: "ali_apache_track", value: `mt=3|ms1=${country}` },
  ];
}

async function setRegionCookies(region) {
  const items = buildCookies(region);
  const exp = expirationDate();
  for (const domain of COOKIE_DOMAINS) {
    for (const c of items) {
      try {
        await chrome.cookies.set({
          url: "https://www.alibaba.com/",
          domain,
          name: c.name,
          value: c.value,
          path: "/",
          secure: true,
          sameSite: "lax",
          expirationDate: exp,
        });
      } catch (e) {
        // 某些 domain 可能因策略写不进，忽略
      }
    }
  }
}

async function getRegion() {
  return new Promise((res) => {
    chrome.storage.sync.get([ENABLED_KEY, REGION_KEY], (r) => {
      res({
        enabled: r && Object.prototype.hasOwnProperty.call(r, ENABLED_KEY) ? !!r[ENABLED_KEY] : true,
        region: (r && r[REGION_KEY]) || DEFAULT_REGION,
      });
    });
  });
}

async function applyIfEnabled() {
  const { enabled, region } = await getRegion();
  if (!enabled) return;
  await setRegionCookies(region);
}

// 安装/启动时写一次
chrome.runtime.onInstalled.addListener(applyIfEnabled);
chrome.runtime.onStartup.addListener(applyIfEnabled);

// 每次导航到 alibaba.com 前都保证 cookie 是 US
chrome.webNavigation.onBeforeNavigate.addListener(
  (details) => {
    if (details.frameId !== 0) return;
    applyIfEnabled();
  },
  { url: [{ hostContains: "alibaba.com" }] }
);

// 监听 popup / storage 变化
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  if (changes[ENABLED_KEY] || changes[REGION_KEY]) {
    applyIfEnabled();
  }
});

// 接收 popup 主动触发
chrome.runtime.onMessage.addListener((msg, sender, sendResp) => {
  if (msg && msg.type === "apply_region") {
    (async () => {
      const region = msg.region || DEFAULT_REGION;
      await chrome.storage.sync.set({ [REGION_KEY]: region, [ENABLED_KEY]: true });
      await setRegionCookies(region);
      sendResp({ ok: true });
    })();
    return true;
  }
  if (msg && msg.type === "clear_region") {
    (async () => {
      // 把刚刚写入的 cookie 删掉，让阿里回到默认行为
      for (const domain of COOKIE_DOMAINS) {
        for (const c of buildCookies(DEFAULT_REGION)) {
          try {
            await chrome.cookies.remove({ url: "https://www.alibaba.com/", name: c.name });
          } catch (_) {}
        }
      }
      await chrome.storage.sync.set({ [ENABLED_KEY]: false });
      sendResp({ ok: true });
    })();
    return true;
  }
});
